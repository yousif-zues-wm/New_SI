(function() {
  'use strict';

  angular
    .module('frontEnd')
    .controller('MusicController', MusicController);


  function MusicController($http, $log) {
      var vm = this;

      vm.test = function(){
        
      }
  }
})();
