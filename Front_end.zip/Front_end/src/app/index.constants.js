/* global malarkey:false, moment:false */
(function() {
  'use strict';

  angular
    .module('frontEnd')
    .constant('malarkey', malarkey)
    .constant('moment', moment);

})();
