(function() {
  'use strict';

  angular
    .module('frontEnd', ['ui.router', 'toastr']);

})();
